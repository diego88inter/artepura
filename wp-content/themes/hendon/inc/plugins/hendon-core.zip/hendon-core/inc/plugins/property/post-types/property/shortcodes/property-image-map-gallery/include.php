<?php

include_once HENDON_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-image-map-gallery/property-image-map-gallery.php';
include_once HENDON_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-image-map-gallery/functions.php';
