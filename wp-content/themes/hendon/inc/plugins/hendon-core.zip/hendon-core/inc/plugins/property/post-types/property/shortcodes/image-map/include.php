<?php

include_once HENDON_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/image-map/image-map.php';
include_once HENDON_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/image-map/functions.php';
