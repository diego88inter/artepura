<a class="qodef-mobile-header-opener" href="#">
    <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
             width="64.584px" height="21.75px" viewBox="0 0 64.584 21.75" enable-background="new 0 0 64.584 21.75" xml:space="preserve">
    <rect x="7.292" y="6.875" fill="#000" width="50" height="1"/>
            <rect x="7.292" y="13.875" fill="#000" width="50" height="1"/>
    </svg>
</a>