<?php

include_once HENDON_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-advanced-info/property-advanced-info.php';