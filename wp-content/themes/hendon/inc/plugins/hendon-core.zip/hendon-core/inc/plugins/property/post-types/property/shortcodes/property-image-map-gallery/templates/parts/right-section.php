<?php echo hendon_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/navigation', '', $params ); ?>

<?php echo hendon_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/image-map', '', $params ); ?>