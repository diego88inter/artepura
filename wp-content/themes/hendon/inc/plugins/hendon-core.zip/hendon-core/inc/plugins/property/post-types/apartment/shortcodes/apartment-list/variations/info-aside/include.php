<?php

include_once HENDON_CORE_PLUGINS_PATH . '/property/post-types/apartment/shortcodes/apartment-list/variations/info-aside/info-aside.php';