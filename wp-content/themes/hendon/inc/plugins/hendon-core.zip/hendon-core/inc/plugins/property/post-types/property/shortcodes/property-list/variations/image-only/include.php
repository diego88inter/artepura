<?php

include_once HENDON_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-list/variations/image-only/image-only.php';